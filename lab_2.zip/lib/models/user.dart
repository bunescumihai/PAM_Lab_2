class User{
  String fullName;
  String location;
  String imagePath;

  User(this.fullName, this.location, this.imagePath);
}