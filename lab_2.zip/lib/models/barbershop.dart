class Barbershop{
  double rating;
  String title;
  String location;
  String imagePath;

  Barbershop(this.title, this.location,this.rating, this.imagePath);

}